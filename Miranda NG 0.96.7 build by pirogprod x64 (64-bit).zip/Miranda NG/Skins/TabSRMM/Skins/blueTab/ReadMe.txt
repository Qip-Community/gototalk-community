********************
*                  *
*    mNoire        *
*                  *
********************

Simple and clean skin for TabSRMM.

**********************
**********************
**                  **
**  How to Install  **
**                  **
**********************
**********************

To enable it, go to Options -> Customize -> Message Window Skin and select the mNoire.tsk file.



********************
*                  *
*     Links        *
*                  *
********************

www.miranda-me.org

********************
*                  *
*     Contact      *
*                  *
********************

chill_hr@mail.ru